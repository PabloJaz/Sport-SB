import ComponenteA from './components/ComponenteA'



const App = () => {
  return (
    <>
      <div>App</div>
      <ComponenteA/>
    </>
  )
}

export default App
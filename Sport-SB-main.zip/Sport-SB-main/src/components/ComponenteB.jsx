import React from 'react'

const ComponenteB = () => {
  return (
    <div>ComponenteB</div>
  )
}

export default ComponenteB
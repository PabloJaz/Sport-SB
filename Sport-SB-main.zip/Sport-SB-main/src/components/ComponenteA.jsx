import React from 'react'

const ComponenteA = () => {
  return (
    <div>ComponenteA</div>
  )
}

export default ComponenteA